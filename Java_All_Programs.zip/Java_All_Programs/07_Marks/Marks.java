import java.util.Scanner;
class Marks {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter three subject marks: ");
  int a=sc.nextInt(), b=sc.nextInt(), c=sc.nextInt();
  int total=a+b+c;
  System.out.println("Total = "+total);
  System.out.println("Average = "+(total/3.0));
 }
}
