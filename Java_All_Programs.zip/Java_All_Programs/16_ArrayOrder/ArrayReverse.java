import java.util.Scanner;
class ArrayReverse {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in); int[] a=new int[5];
  System.out.println("Enter 5 numbers:");
  for(int i=0;i<5;i++) a[i]=sc.nextInt();
  System.out.println("Original order:");
  for(int x:a) System.out.print(x+" ");
  System.out.println("\nReverse order:");
  for(int i=4;i>=0;i--) System.out.print(a[i]+" ");
  System.out.println();
 }
}
