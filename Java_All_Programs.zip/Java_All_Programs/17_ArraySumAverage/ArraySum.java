import java.util.Scanner;
class ArraySum {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter array size: "); int n=sc.nextInt();
  if(n<=0){System.out.println("Size must be positive.");return;}
  int[] a=new int[n]; int sum=0;
  System.out.println("Enter "+n+" numbers:");
  for(int i=0;i<n;i++){a[i]=sc.nextInt();sum+=a[i];}
  System.out.println("Sum = "+sum);
  System.out.println("Average = "+((double)sum/n));
 }
}
