class BankAccount {
 private double balance=1000;
 class AccountDetails {
  void updateBalance(){balance+=500;System.out.println("Updated Balance = "+balance);}
 }
 static class Receipt {
  void printReceipt(){System.out.println("Bank receipt printed.");}
 }
 interface Notifier { void sendMessage(); }
 void notifyUser(Notifier n){n.sendMessage();}
 public static void main(String[] args) {
  BankAccount account=new BankAccount();
  BankAccount.AccountDetails details=account.new AccountDetails();
  details.updateBalance();
  BankAccount.Receipt receipt=new BankAccount.Receipt();
  receipt.printReceipt();
  account.notifyUser(new BankAccount.Notifier(){
   public void sendMessage(){System.out.println("Account updated successfully.");}
  });
 }
}
