import java.util.Scanner;
class Swap {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter two numbers: ");
  int a=sc.nextInt(), b=sc.nextInt();
  System.out.println("Before: "+a+" "+b);
  int temp=a; a=b; b=temp;
  System.out.println("After: "+a+" "+b);
 }
}
