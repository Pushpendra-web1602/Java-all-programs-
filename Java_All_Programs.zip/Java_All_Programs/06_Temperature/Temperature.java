import java.util.Scanner;
class Temperature {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter Celsius: "); double c=sc.nextDouble();
  System.out.println("Fahrenheit = "+((c*9.0/5.0)+32));
 }
}
