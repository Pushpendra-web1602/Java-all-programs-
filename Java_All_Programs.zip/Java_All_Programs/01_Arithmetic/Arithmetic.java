import java.util.Scanner;
class Arithmetic {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter two numbers: ");
  int a=sc.nextInt(), b=sc.nextInt();
  System.out.println("Sum = "+(a+b));
  System.out.println("Difference = "+(a-b));
  System.out.println("Product = "+(a*b));
  if(b!=0) System.out.println("Quotient = "+(a/(double)b));
  else System.out.println("Division by zero not allowed");
 }
}
