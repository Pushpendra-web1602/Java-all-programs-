JAVA PROGRAMMING PRACTICE - 21 PROGRAMS

Each program is stored in a separate folder to avoid class-name conflicts.

How to run:
1. Open the required folder in Command Prompt or Terminal.
2. Compile: javac FileName.java
3. Run: java ClassName

Example:
  cd 01_Arithmetic
  javac Arithmetic.java
  java Arithmetic

Included: arithmetic, rectangle, circle, greeting, bill, temperature, marks,
days conversion, swapping, strings, vowels, initials, arrays, abstract class,
interface, inner class, static nested class and anonymous class.
