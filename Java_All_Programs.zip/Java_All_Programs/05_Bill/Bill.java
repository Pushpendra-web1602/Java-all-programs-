import java.util.Scanner;
class Bill {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter price: "); double price=sc.nextDouble();
  System.out.print("Enter quantity: "); int qty=sc.nextInt();
  System.out.printf("Total Bill = %.2f%n",price*qty);
 }
}
