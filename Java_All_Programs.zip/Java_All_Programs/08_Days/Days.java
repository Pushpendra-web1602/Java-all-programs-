import java.util.Scanner;
class Days {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter total days: "); int days=sc.nextInt();
  int years=days/365, rem=days%365, weeks=rem/7, remainingDays=rem%7;
  System.out.println("Years = "+years);
  System.out.println("Weeks = "+weeks);
  System.out.println("Remaining days = "+remainingDays);
 }
}
