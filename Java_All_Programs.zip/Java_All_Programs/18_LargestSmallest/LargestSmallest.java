import java.util.Scanner;
class LargestSmallest {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter array size: "); int n=sc.nextInt();
  if(n<=0){System.out.println("Size must be positive.");return;}
  int[] a=new int[n];
  for(int i=0;i<n;i++) a[i]=sc.nextInt();
  int largest=a[0], smallest=a[0];
  for(int i=1;i<n;i++){if(a[i]>largest)largest=a[i];if(a[i]<smallest)smallest=a[i];}
  System.out.println("Largest = "+largest);
  System.out.println("Smallest = "+smallest);
 }
}
