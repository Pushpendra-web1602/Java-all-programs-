abstract class General {
 String name;
 General(String name){this.name=name;}
 void showName(){System.out.println("Name: "+name);}
 abstract void printReceipt();
}
class Payment extends General {
 Payment(String name){super(name);}
 void printReceipt(){System.out.println("Payment receipt generated.");}
}
class Employee extends General {
 Employee(String name){super(name);}
 void printReceipt(){System.out.println("Employee salary receipt generated.");}
}
class Vehicle extends General {
 Vehicle(String name){super(name);}
 void printReceipt(){System.out.println("Vehicle receipt generated.");}
}
class AbstractDemo {
 public static void main(String[] args) {
  General[] objects={new Payment("Online Payment"),new Employee("Ravi"),new Vehicle("Car")};
  for(General g:objects){g.showName();g.printReceipt();System.out.println();}
 }
}
