import java.util.Scanner;
class Characters {
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  System.out.print("Enter a string: "); String s=sc.nextLine();
  if(s.length()>=3) {
   System.out.println("First = "+s.charAt(0));
   System.out.println("Last = "+s.charAt(s.length()-1));
   System.out.println("Third = "+s.charAt(2));
  } else System.out.println("Enter at least 3 characters.");
 }
}
